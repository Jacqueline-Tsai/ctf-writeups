Bot code reference: https://github.com/splitline/My-CTF-Challenges/tree/master/hitcon-ctf/2022/web/sdm/bot

You don't need to read the code of the bot part, it has nothing to do with the solution, it is just attached for the convenience of local debugging